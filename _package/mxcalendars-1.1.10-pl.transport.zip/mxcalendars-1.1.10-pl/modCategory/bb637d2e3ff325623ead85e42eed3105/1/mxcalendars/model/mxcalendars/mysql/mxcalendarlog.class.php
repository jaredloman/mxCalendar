<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendarlog.class.php');
class mxCalendarLog_mysql extends mxCalendarLog {}