<?php
class mxCalendarLog extends xPDOSimpleObject {}