<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendarevents.class.php');
class mxCalendarEvents_mysql extends mxCalendarEvents {}