<?php
class mxCalendarEventWUG extends xPDOSimpleObject {}